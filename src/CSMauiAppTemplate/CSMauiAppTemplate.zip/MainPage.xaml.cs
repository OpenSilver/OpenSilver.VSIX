﻿using OpenSilver.Maui;

namespace $safeprojectname$
{
    public partial class MainPage : ContentPage
    {
        private IWebViewManagerService _webViewManagerService;

        public MainPage(IWebViewManagerService webViewManagerService)
        {
            _webViewManagerService = webViewManagerService;

            InitializeComponent();

            this.Loaded += MainPage_Loaded;
        }

        private async void MainPage_Loaded(object? sender, EventArgs e)
        {
            await _webViewManagerService.InitializeWebViewAsync(blazorWebView, () => { var app = new $safeprojectname$.App(); });
        }
    }
}