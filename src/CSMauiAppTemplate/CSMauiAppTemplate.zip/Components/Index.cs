﻿using Microsoft.AspNetCore.Components;

namespace $safeprojectname$.Components
{
    [Route("/")]
    public class Index : ComponentBase
    {
    }
}