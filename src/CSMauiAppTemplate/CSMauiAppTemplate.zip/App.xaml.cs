﻿using OpenSilver.Maui;

namespace $safeprojectname$
{
    public partial class App : Application
    {
        public App(IWebViewManagerService webViewManagerService)
        {
            InitializeComponent();

            MainPage = new MainPage(webViewManagerService);
        }
    }
}