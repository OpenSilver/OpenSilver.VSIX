﻿using System.Windows;
using System.Windows.Controls;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : ChildWindow
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

