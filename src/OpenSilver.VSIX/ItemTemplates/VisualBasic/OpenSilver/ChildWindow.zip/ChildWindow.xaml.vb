﻿Imports System.Windows
Imports System.Windows.Controls

Partial Public Class $safeitemname$
    Inherits ChildWindow
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub OKButton_Click(sender As Object, e As RoutedEventArgs)
        Me.DialogResult = true
    End Sub

    Private Sub CancelButton_Click(sender As Object, e As RoutedEventArgs)
        Me.DialogResult = false
    End Sub
End Class

