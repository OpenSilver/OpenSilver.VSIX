﻿namespace $rootnamespace$

open System.Windows
open System.Windows.Controls

type $safeitemname$() as this =
    inherit $safeitemname$Xaml()

    do
        this.InitializeComponent()

    member private this.OKButton_Click(sender: obj, e: RoutedEventArgs) =
        this.DialogResult <- true

    member private this.CancelButton_Click(sender: obj, e: RoutedEventArgs) =
        this.DialogResult <- false

