﻿namespace $rootnamespace$

open System
open System.Collections.Generic
open System.Linq
open System.Text
open System.Threading.Tasks

type $safeitemname$ =
    member this.DummyMethod() =
        ()

